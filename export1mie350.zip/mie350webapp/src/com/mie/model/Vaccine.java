package com.mie.model;

import java.util.Date;

public class Vaccine {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Student object.
	 */

	private String vaccineID;
	private String vaccineName;
	private Boolean reocurring;
	private int nextY;
	private int nextM;
	private int nextD;
	private Boolean live;
	private String diseases_prevented;



	public String getVaccineid() {
		return vaccineID;
	}

	public void setVaccineid(String vaccineID) {
		this.vaccineID = vaccineID;
	}

	public String getVaccineName() {
		return vaccineName;
	}

	public void setVaccName(String vaccineName) {
		this.vaccineName = vaccineName;
	}

	public Boolean getReoccurring() {
		return reocurring;
	}

	public void setReocurring(Boolean reocurring) {
		this.reocurring = reocurring;
	}

	public int getNextY() {
		return nextY;
	}
	
	public int getNextM() {
		return nextM;
	}
	
	public int getNextD() {
		return nextD;
	}

	public void setNextY(int nextY) {
		this.nextY = nextY;
	}
	
	public void setNextM(int nextM) {
		this.nextM = nextM;
	}
	
	public void setNextD(int nextD) {
		this.nextD = nextD;
	}
	
	public Boolean getLive() {
		return live;
	}
	
	public void setLive(Boolean live) {
		this.live = live;
	}
	
	public String getDiseasePrevented() {
		return diseases_prevented;
	}
	
	public void setDisease(String disease) {
		this.diseases_prevented = disease;
	}
	



	@Override
	public String toString() {
		return "Vaccine [Vaccine ID=" + vaccineID + ", Vaccine Name=" + vaccineName
				+ ", Reoccurring=" + reocurring + ", Second Dosage Date =" + nextY + " years,"+ nextM + " months," + nextD + " days, Live= "+ live +", Diseases Prevented= " +diseases_prevented+ "]";
	}
}


