package com.mie.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.Student;
import com.mie.model.Vaccine;
import com.mie.util.DbUtil;

public class VaccineDao {
	
	private Connection connection;

	public VaccineDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}
	
	public List<Vaccine> getVaccines(int patientID) {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		List<Vaccine> vaccines = new ArrayList<Vaccine>();
		try {
			Statement statement = connection.createStatement();
			// System.out.println("getting students from table");
			ResultSet rs = statement.executeQuery("SELECT * FROM VaccineRecords INNER JOIN VaccineList ON VaccineRecords.VaccineID=VaccineList.VaccID WHERE VaccineRecords.patientID="+patientID);
			while (rs.next()) {
				Vaccine vaccine = new Vaccine();
				vaccine.setVaccineid(rs.getString("vaccineID"));
				vaccine.setVaccName(rs.getString("VaccineName"));
				vaccine.setReocurring(rs.getBoolean("reocurring"));
				vaccine.setNextY(rs.getInt("Second Dosage Years"));
				vaccine.setNextM(rs.getInt("Second Dosage Months"));
				vaccine.setNextD(rs.getInt("Second Dosage Days"));
				vaccine.setLive(rs.getBoolean("live"));
				vaccine.setDisease(rs.getString("diseases_prevented"));

				vaccines.add(vaccine);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return vaccines;
	}
	

}
