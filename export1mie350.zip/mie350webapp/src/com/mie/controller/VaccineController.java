package com.mie.controller;

public class VaccineController {

}
